<?php
class dbManagerlocal
{
    protected static $connection;
    public function connect()
    {

        /*
        Funcion que nos devuelve la conexión hacia la base de datos, notese que obtengo
        las credenciales desde un archivo de configuracion, evitando colocar las mismas en el script

        */
        if (!isset(self::$connection))
        {
            $config = parse_ini_file("config_local.ini");
            self::$connection = new mysqli('localhost',$config['username'],$config['password'],$config['dbname']);
        }

        if (self::$connection === false)
        {
            return false;
        }

        return self::$connection;
    }

    public function query($query)
    {
        /*
        Se utiliza en sentencias DML (Manipulación de Datos)
        Realiza una consulta a la base de datos
        Si es una sentencia Select retorna un objeto mysqli_result
        Si es una instruccion (INSERT, DELETE, UPDATE) returna True o False

        */
        $connection = $this->connect();

        $result = $connection->query($query);

        return $result;
    }

    public function select($query)
    {
        /*
        Funcion que devuelve un array con los datos resultantes de la consulta
        */
        $rows = array();
        $result = $this->query($query);
        if ($result === false)
        {
            return false;
        }

        while($row = $result->fetch_assoc())
        {
            $rows[] = $row;
        }

        return $rows;
    }

    public function error()
    {
        /*
        Devuelve una cadena que describe el ultimo error
        */
        $connection = $this->connect();
        return $connection->error;
    }

    public function quote($value)
    {

        /*
        Escapa los caracteres especiales de una cadena para usarla
        en una sentencia SQL
        pensado para inyeccion SQL
        */
        $connection = $this->connect();
        return "'" . $connection->real_escape_string($value) . "'";

    }

}

?>