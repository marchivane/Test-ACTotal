<?php
	
	include('../config/conexion.php');
	

	date_default_timezone_set("America/Caracas"); 


	$nombre=$_POST['nombre'];
	$email=$_POST['email'];
	$telefono=$_POST['telefono'];
	$fecha=$newDia = date("d/m/Y");
	
	$sentencia = $mysqli->prepare("insert into datos (nombre,email,telefono,fecha) VALUES (?, ?, ?,?)");  
    $sentencia->bind_param("ssis",$nombre,$email,$telefono,$fecha);	
    $sentencia->execute();
	
	

	$html="si";
	
	echo json_encode($html);