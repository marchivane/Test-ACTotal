<?php
 $mysqli = include_once "config/conexion.php"; 
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <title>Test ACTotal</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="icons/icomoon.css">
    <link rel="stylesheet" href="css/estilos.css">
	
</head>

<body>

    <!-- Contenedor Header -->
    <header id="linkHome">
        <nav id="navFixed" class="navbar fixed-top navbar-expand-lg navbar-light bg-light p-10px">
            <a class="navbar-brand" href="#linkHome">ACTotal<small>.</small></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link scroll current" href="#linkHome">ACTotal</a>
                    </li>
                    

                </ul>
            </div>
        </nav>

    </header>
    <!-- Fin Contenedor Header -->

    

        <!-- Sección Contacto -->
        <section class="boxContacto" id="linkContacto">
            

            <div class="container contacto"><h3>Ingreso de Datos</h3>
                <form id="miForm">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputName"><b>Nombre</b></label>
                            <input type="text" class="form-control" id="nombre" placeholder="Nombre..." required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputLastName"><b>Email</b></label>
                            <input type="text" class="form-control" id="email" placeholder="Correo..." required pattern="[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{1,5}">
                        </div>
						<div class="form-group col-md-6">
                            <label for="inputLastName"><b>Teléfono</b></label>
                            <input type="number" class="form-control" id="telefono" placeholder="Teléfono..." oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
    type = "number"
    maxlength = "9" required>
                        </div>
                    </div>

                    


                    <button type="button" class="botonEnviarMensaje" onclick="Guardar()">Guardar</button>
                </form>
            </div>
			
			
			<div class="container tabla">
                <h3>Listado de Datos</h3>
				<div class="divTable">
<div class="divTableHeading">
<div class="divTableRow">
<div class="divTableHead">Nombe Completo</div>
<div class="divTableHead">Email</div>
<div class="divTableHead">Teléfono</div>
<div class="divTableHead">Fecha Registro</div>
</div>
</div>
<div class="divTableBody">
<?php
$resultado = $mysqli->query("select * from datos");
$datos = $resultado->fetch_all(MYSQLI_ASSOC);

$cnt=1;
// while($row=mysqli_fetch_array($sql))
foreach ($datos as $row)
{
?>
<div class="divTableRow">
<div class="divTableCell"><?php echo $row['nombre'] ;?></div>
<div class="divTableCell"><?php echo $row['email'] ;?></div>
<div class="divTableCell"><?php echo $row['telefono'] ;?></div>
<div class="divTableCell"><?php echo $row['fecha'] ;?></div>
</div>


<?php 
$cnt=$cnt+1;
											 }?>
</div>

</div>
				
				
				
            </div>
        </section>				 
        <!-- Sección Contacto -->
		
		
		

    </main>
    <!-- Fin Contenedor Main -->



    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<script src="js/jquery.min.js"></script>    
    <script src="js/app.js"></script>
	

</body>

</html>

<script>


</script>