function Guardar() {
	
	var nombre=$('#nombre').val();
	var email=$('#email').val();
	var telefono=$('#telefono').val();;
	
	if(nombre=="" || email=="")
	{
		alert("El campo nombre y correo deben ser obligatorios.");
		javascript:location.reload();
	}
	else
	{
		$.ajax({
			url: './model/guardar.php',
			dataType: "json",
			type: 'POST',
			data: {nombre:nombre,email:email,telefono:telefono},
			success:function(data){
				
				if(data=="si"){							
					alert("Datos guardados correctamente.");
					javascript:location.reload();
				}
				
			}
		});
	}
	
			
	
}

jQuery(document).ready(function() {
				var c=$(".divTableRow").length;
					if(c>8){						
						$(".divTable").css('overflow-y','scroll') ;
						$(".divTable").css('overflow-x','hidden') ;
						$(".divTable").css('height','220px') ;
					}
			});